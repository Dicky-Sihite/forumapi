/* eslint-disable import/no-extraneous-dependencies */
require('dotenv').config();
