class AddedReply {
  constructor({ id, content, owner }) {
    this.id = id;
    this.content = content;
    this.owner = owner;
  }
}

module.exports = AddedReply;